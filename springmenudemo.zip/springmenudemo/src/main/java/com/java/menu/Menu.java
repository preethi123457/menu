package com.java.menu;

import javax.persistence.Entity;

import org.springframework.data.annotation.Id;

@Entity
public class Menu {
	
	private int MEN_ID;
    private String MEN_ITEM;
    private double MEN_PRICE;
    private int MEN_CALORIES;
    private String MEN_SPECIALITY;
      	@Id
       public int getMEN_ID() {
		return MEN_ID;
	}
	public void setMEN_ID(int MEN_ID) {
		this.MEN_ID = MEN_ID;
	}
	public String getMEN_ITEM() {
		return MEN_ITEM;
	}
	public void setMEN_ITEM(String MEN_ITEM) {
		this.MEN_ITEM = MEN_ITEM;
	}
	public double getMEN_PRICE() {
		return MEN_PRICE;
	}
	public void setMEN_PRICE(double MEN_PRICE) {
		this.MEN_PRICE = MEN_PRICE;
	}
	public int getMEN_CALORIES() {
		return MEN_CALORIES;
	}
	public void setMEN_CALORIES(int MEN_CALORIES) {
		this.MEN_CALORIES = MEN_CALORIES;
	}
	public String getMEN_SPECIALITY() {
		return MEN_SPECIALITY;
	}
	public void MEN_SPECIALITY(String MEN_SPECIALITY) {
		this.MEN_SPECIALITY= MEN_SPECIALITY;
	}
}


